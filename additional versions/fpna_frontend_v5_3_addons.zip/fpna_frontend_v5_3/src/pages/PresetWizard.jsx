import React, { useEffect, useState } from 'react'
import { makeClient } from '../api'

export default function PresetWizard({api, token, year, scenario}){
  const [catalog, setCatalog] = useState([])
  const [preset_type, setPresetType] = useState('qsr')
  const [name, setName] = useState('Unit-1')
  const [apply, setApply] = useState(true)
  const [count, setCount] = useState(0); const [sample, setSample] = useState([])

  useEffect(()=>{ (async()=>{ try{ const client = makeClient(api, token); const { data } = await client.get('/presets/catalog'); setCatalog(data.presets||[]) }catch(e){} })() }, [api, token])

  async function run(){
    const client = makeClient(api, token)
    const { data } = await client.post('/presets/generate', { preset_type, year, scenario, name, apply })
    setCount(data.rows); setSample(data.sample||[])
  }

  return (
    <div className="bg-white rounded-2xl shadow p-4 space-y-3">
      <div className="font-medium">Preset Library</div>
      <div className="flex flex-wrap gap-3 items-end">
        <div><label className="text-sm">Preset</label>
          <select className="border rounded px-2 py-1" value={preset_type} onChange={e=>setPresetType(e.target.value)}>
            {catalog.map(p => <option key={p.key} value={p.key}>{p.label}</option>)}
          </select>
        </div>
        <div><label className="text-sm">Name</label><input className="border rounded px-2 py-1" value={name} onChange={e=>setName(e.target.value)} /></div>
        <label className="text-sm flex items-center gap-2"><input type="checkbox" checked={apply} onChange={e=>setApply(e.target.checked)} />Apply</label>
        <button onClick={run} className="px-3 py-2 rounded bg-slate-900 text-white">Generate</button>
      </div>
      {count>0 && <div className="text-sm">Created {count} rows. Sample:</div>}
      {sample.length>0 && <pre className="bg-slate-100 rounded p-2 text-xs overflow-auto">{JSON.stringify(sample,null,2)}</pre>}
    </div>
  )
}