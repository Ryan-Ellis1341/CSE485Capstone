import React from 'react'
import { ResponsiveContainer, LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, Legend } from 'recharts'
export default function MultiLine({data, lines=[{key:'revenue',label:'Revenue'},{key:'cogs',label:'COGS'},{key:'opex',label:'Opex'}], title='Series'}){
  return (
    <div className="bg-white rounded-2xl shadow p-4">
      <div className="font-medium mb-2">{title}</div>
      <div style={{width:'100%', height:320}}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" /><YAxis /><Tooltip /><Legend />
            {lines.map((l,i)=> <Line key={i} type="monotone" dataKey={l.key} name={l.label} dot={false} />)}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}