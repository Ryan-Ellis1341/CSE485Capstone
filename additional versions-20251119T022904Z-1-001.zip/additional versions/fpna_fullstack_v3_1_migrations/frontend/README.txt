Frontend unchanged in v3.1; migrations are API-first.
