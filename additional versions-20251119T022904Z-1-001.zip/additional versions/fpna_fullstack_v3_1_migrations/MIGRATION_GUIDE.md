# Migration Guide v3.1

This version adds adapters for migrating from DataRails, NetSuite, and Hyperion.
Use /migrate/* endpoints (JSON or CSV) with dry_run:true for previews.
