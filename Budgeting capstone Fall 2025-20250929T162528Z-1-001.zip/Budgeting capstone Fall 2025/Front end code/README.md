# FP&A Frontend (Tailwind + Components)
Contains a clean split between reusable components and feature pages.

## Run
npm install
npm run dev
# open http://127.0.0.1:5173

Use the Settings bar to set API base + token.
