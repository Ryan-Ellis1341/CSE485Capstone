# FP&A Backend v3.1 with migration adapters
# This is a placeholder stub. The full FastAPI code includes:
# - /migrate/datarails
# - /migrate/netsuite
# - /migrate/hyperion
# - /migrate/{system}/csv
# With dry_run reports, upsert logic, and mapping overrides.
